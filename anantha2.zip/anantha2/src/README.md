# The project is run with server.py flask app
# To run local queries run boolean_retrieval_runner.py
# To validate the tests script_sampler.py was used
# Base.py is a test codew and not the main runner. (Boolean retrieval runner and server are the main ones)

